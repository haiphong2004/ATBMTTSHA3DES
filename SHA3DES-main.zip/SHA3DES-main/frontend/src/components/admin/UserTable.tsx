import React from "react";

const UserTable = () => {
  return <div>User Table Component</div>;
};

export default UserTable;