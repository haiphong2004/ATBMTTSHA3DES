import React from "react";

const FormInput = () => {
  return <div>Form Input Component</div>;
};

export default FormInput;